﻿using Core.Models.Cart;
using Dapper;
using Domain;
using Infrastructure.Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class CartService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly SqlConnection _connection;
        public CartService(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
            _connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));   
        }

        public async Task<int> CreateCart(int UserIdDto)
        {
            var existingcart = await _context.CartMaster.Where(c => c.UserId == UserIdDto).FirstOrDefaultAsync();
            if (existingcart == null)
            {
                var cart = new CartMaster { UserId = UserIdDto };
                await _context.CartMaster.AddAsync(cart);
                await _context.SaveChangesAsync();
                return cart.Id;
            }
            return existingcart.Id;
        }

        public async Task <CartDetails> addToCart(CartDetailDto dto)
        {
            var existingProduct = await _context.CartDetails.Where(c=>c.CartId == dto.CartId && c.productId == dto.productId).FirstOrDefaultAsync();
            if(existingProduct == null)
            {
                var cartdetail = new CartDetails
                {
                    CartId = dto.CartId,
                    productId = dto.productId,
                    quantity = dto.quantity,
                };

                await _context.CartDetails.AddAsync(cartdetail);
                await _context.SaveChangesAsync();
                return cartdetail;
            }
            var ProductDetail = await _context.ProductMaster.Where(p => p.Id == dto.productId).FirstOrDefaultAsync();
            if (existingProduct.quantity < ProductDetail.Stock)
            {
                existingProduct.quantity += dto.quantity;
                await _context.SaveChangesAsync();
                return existingProduct;
            }
            return null;
        }

        public async Task <IEnumerable<getCartDataResponse>> getCartDetails(int Id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Id", Id);

            var result = await _connection.QueryAsync<getCartDataResponse>("getCartData", parameters, commandType: CommandType.StoredProcedure);
            return result;

        }

        public async Task<string> removeFromCart(int productId,int CartId)
        {
            var existingProduct = await _context.CartDetails.Where(c=>c.CartId == CartId && c.productId == productId).FirstOrDefaultAsync();
            if(existingProduct != null)
            {
                 _context.CartDetails.Remove(existingProduct);
                await _context.SaveChangesAsync();
                return "success";
            }
            else
            {
                return "unsuccessful";
            }
        }

        public async Task <string> decrementQuantity(decrementQuantityDto dto)
        {
            var existingProduct = await _context.CartDetails.Where(c => c.CartId == dto.CartId && c.productId == dto.ProductId).FirstOrDefaultAsync();
            if(existingProduct != null)
            {
                if (existingProduct.quantity > 1)
                {
                    existingProduct.quantity -= dto.Quantity;
                    await _context.SaveChangesAsync();
                    return "success";
                }
                else
                {
                    var result = await removeFromCart(dto.ProductId, dto.CartId);
                    return result;
                }
            }

            return "unsuccessful";

        }

    }
}
