﻿using Core.Interfaces;
using Domain;
using Infrastructure.Database;
using Core.Models.User;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

namespace Infrastructure.Services
{
    public class UserService
    {
        private readonly AppDbContext _context;
        
        private readonly IEmailService _emailService;
        private readonly IWebHostEnvironment _env;

        public UserService(AppDbContext context, IEmailService emailService, IWebHostEnvironment env)
        {
            _context = context;
            _emailService = emailService;
            _env = env;
        }

        public async Task<User> getUserInfo(string Username)
        {
            var existingUser = await _context.Users.Where(u=>u.UserName == Username).FirstOrDefaultAsync();
            if (existingUser != null) 
            {
                return existingUser;
            }
            return null;
        }

        public async Task<string> updateUserInfo(userUpdateDto dto)
        {
            var existingUser = await _context.Users.Where(u=>u.UserName == dto.UserName).FirstOrDefaultAsync();

            string profileImagePath = ImagePath(dto.ProfileImage);

            if (existingUser != null)
            {
                if (profileImagePath != "")
                {
                existingUser.ProfileImage = profileImagePath;
                }
                else
                {
                 existingUser.ProfileImage = $"/profile_images/default.jpg";
                }
                existingUser.FirstName = dto.FirstName;
                existingUser.LastName = dto.LastName;
                existingUser.Email = dto.Email;
                existingUser.Dob = dto.Dob;
                existingUser.Mobile = dto.Mobile;
                existingUser.AddressLine1 = dto.AddressLine1;
                existingUser.AddressLine2 = dto.AddressLine2;
                existingUser.zipcode = dto.zipcode;
                existingUser.CountryId = dto.CountryId;
                existingUser.StateId = dto.StateId;

                 await _context.SaveChangesAsync();
                return "success";
            }
            return "unsuccessful";
        }

        public async Task<string> updateUserAddress(userUpdateAddressDto dto)
        {
            var existingUser = await _context.Users.Where(u=>u.UserName == dto.UserName).FirstOrDefaultAsync();
            if (existingUser != null)
            {
                existingUser.AddressLine1 = dto.AddressLine1;
                existingUser.AddressLine2 = dto.AddressLine2;
                await _context.SaveChangesAsync();
                return "success";
            }
            return "unsuccessful";
        }


        public string ImagePath(IFormFile image)
        {
            if (image != null || image.Length != 0)
            {

                var folderPath = Path.Combine(_env.WebRootPath, "profile_images");

                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);

                
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream); 
                }

                return $"/profile_images/{fileName}";

            }
            return "";
        }
    }
}
