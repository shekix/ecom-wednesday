﻿using Core.Models.User;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;

namespace E_commerce_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public RegistrationLoginService _registrationService;
        public UserService _userService;
        public UserController(RegistrationLoginService registrationService,UserService userService)
        {
            _registrationService = registrationService;
            _userService = userService;
        }

        [HttpPost("Register")]
        public async Task<IActionResult> userRegistration( userRegistrationDto dto)
        {
            var result = await _registrationService.userRegistration(dto);
            if(result != null)
            {
                return Ok(result);
            }
            return Conflict("user with this email already exists");
        }

        [HttpPost("Login")]
        public async Task<IActionResult> userLogin(userLoginDto dto)
        {
            var result = await _registrationService.userLogin(dto);
            if (result)
            {
                return Ok("Successful");
            }
            return Unauthorized("unsuccessfulLogin");
        }

        [HttpPost("2FA")]
        public async Task <IActionResult> userVerification(OtpVerficationDto dto)
        {
            var result = await _registrationService.userVerification(dto);
            if(result == "unsuccessful")
            {
                return BadRequest("unsuccessful");
            }
            return Ok(result);
        }

        [HttpPost("ForgotPass")]
        public async Task<IActionResult> forgotPass(string email)
        {
            var result = await _registrationService.forgotPassword(email);
            if(result == "unsuccessful")
            {
                return NotFound(email);
            }
            return Ok(result);
        }

        [HttpPut("ChangePass")]
        public async Task<IActionResult> changePass(userChangePassDto dto)
        {
            var result = await _registrationService.changePassword(dto);
            if(result == "unsuccessful")
            {
                return BadRequest();
            }
            return Ok(result);
        }

        [HttpGet("roles")]
        public async Task<IActionResult> Roles()
        {
            var result = await _registrationService.roles();
            return Ok(result);
        }

        [HttpGet("user")]
        public async Task<IActionResult> userById(string username)
        {
            var result = await _userService.getUserInfo(username);
            return Ok(result);
        }

        [HttpPut("user")]
        public async Task<IActionResult> updateUser(userUpdateDto dto)
        {
            var result = await _userService.updateUserInfo(dto);
            if (result == "success")
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpPut("address")]
        public async Task<IActionResult> updateAddress(userUpdateAddressDto dto)
        {
            var result = await _userService.updateUserAddress(dto);
            if (result == "success")
            {
                return Ok(result);
            }
            return BadRequest(result);
        }
    }
}
