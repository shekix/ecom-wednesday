﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.User
{
   public class OtpVerficationDto
    {
        public string Username { get; set; }
        public string Otp {  get; set; }
    }
}
