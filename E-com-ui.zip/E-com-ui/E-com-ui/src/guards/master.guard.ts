import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const masterGuard: CanActivateFn = (route, state) => {
  var service = inject(AuthService);

  return service.isLoggedin();
};
