import { Component, DoCheck, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { ProfileComponent } from "../profile/profile.component";
import { ProductMasterComponent } from '../product-master/product-master.component';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterOutlet, RouterLink,ProductMasterComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
role = sessionStorage.getItem("role");
userId =sessionStorage.getItem("id")
pfp:any;
username = sessionStorage.getItem('username');
userinfo:any;
cartSize:number = 0;
constructor(private userSerice:UserService,private route:Router,private authService:AuthService){}

ngOnInit(): void {
    this.userSerice.getUser(this.username).subscribe((data:any)=>{
    this.userinfo = data;
    console.log(data);
    this.pfp = "https://localhost:7051"+this.userinfo.profileImage
    })

}

logout(){
  this.authService.logout();
  this.route.navigate(['/login'])
}


}
