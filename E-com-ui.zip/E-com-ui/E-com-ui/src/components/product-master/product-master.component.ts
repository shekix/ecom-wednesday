import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import * as bootstrap from 'bootstrap';
import { CurrencyPipe, formatDate } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-master',
  standalone: true,
  imports: [CurrencyPipe,ReactiveFormsModule],
  templateUrl: './product-master.component.html',
  styleUrl: './product-master.component.css'
})
export class ProductMasterComponent implements OnInit {
products:any;

selectedFile:File | string = "";
selectedFileEdit:File | string = "";

productdetail= {
  img:'',
  name:'',
  productcode:'',
  brand:'',
  category:'',
  sellingPrice:'',
  purchasePrice:'',
  purchaseDate:'',
  stock:'',
}

constructor(private service:ProductService){}


addProductForm = new FormGroup({
  productCode:new FormControl('', [Validators.required,Validators.minLength(6),Validators.maxLength(6),Validators.pattern("^[a-zA-Z0-9]{6}$")]),
  name:new FormControl('', [Validators.required]),
  brand:new FormControl('', [Validators.required]),
  category:new FormControl('', [Validators.required]),
  sellingPrice:new FormControl(0, [Validators.required,Validators.pattern("^[0-9]*$")]),
  purchasePrice:new FormControl(0, [Validators.required,Validators.pattern("^[0-9]*$")]),
  purchaseDate:new FormControl('', [Validators.required]),
  stock:new FormControl('', [Validators.required,Validators.pattern("^[0-9]*$")]),
})


editProductForm = new FormGroup({
  productCode:new FormControl(''),
  name:new FormControl('', [Validators.required]),
  brand:new FormControl('', [Validators.required]),
  category:new FormControl('', [Validators.required]),
  sellingPrice:new FormControl(0, [Validators.required,Validators.pattern("^[0-9]*$")]),
  purchasePrice:new FormControl(0, [Validators.required,Validators.pattern("^[0-9]*$")]),
  purchaseDate:new FormControl('', [Validators.required]),
  stock:new FormControl('', [Validators.required,Validators.pattern("^[0-9]*$")]),
})

getProducts(){
  this.service.getProducts().subscribe((data:any)=>{
    this.products = data;
  }) 
}

ngOnInit(): void {
this.getProducts()
}

addModal(){
  const modal = new bootstrap.Modal(document.getElementById('addModal')!);

  modal.show();
}


onFileChanged(event: any) {
  const file = event.target.files[0];
  if (file) {
    this.selectedFile = file;
  }
}

onFileChangedEdit(event: any) {
  const file = event.target.files[0];
  if (file) {
    this.selectedFileEdit = file;
  }
}

onSubmit(){
  console.log(this.addProductForm.value);
  
  if (this.addProductForm.valid ) {

        const formData = new FormData();
        Object.keys(this.addProductForm.value).forEach((key) => {
          formData.append(key, this.addProductForm.get(key)?.value || "");
        });
        formData.append('productImage', this.selectedFile);
      
        this.service.addProduct(formData).subscribe((data:any)=>{
          alert('product added');
          this.addProductForm.reset();
          const modal = new bootstrap.Modal(document.getElementById('viewModal')!);
      
          modal.hide();
          this.getProducts();
        });   
}
}

onView(item:any){
  this.productdetail = {
    img:"https://localhost:7051"+item.productImage,
    name:item.name,
    productcode:item.productCode,
    brand:item.brand,
    category:item.category,
    sellingPrice:item.sellingPrice,
    purchasePrice:item.purchasePrice,
    purchaseDate:formatDate(item.purchaseDate,'yyyy-MM-dd','en'),
    stock:item.stock
  }

  const modal = new bootstrap.Modal(document.getElementById('viewModal')!);

  modal.show();

}


onEdit(item:any)
{
  this.editProductForm.patchValue({
    productCode:item.productCode,
    name:item.name,
    brand:item.brand,
    category:item.category,
    sellingPrice:item.sellingPrice,
    purchasePrice:item.purchasePrice,
    purchaseDate:formatDate(item.purchaseDate,'yyyy-MM-dd','en'),
    stock:item.stock
  })

  const modal = new bootstrap.Modal(document.getElementById('editModal')!);

  modal.show();

}

saveChanges(){
  const formData = new FormData();
  Object.keys(this.editProductForm.value).forEach((key) => {
    formData.append(key, this.editProductForm.get(key)?.value || "");
  });
  formData.append('productImage', this.selectedFileEdit);

  this.service.updateProduct(formData).subscribe((res:any)=>{
    if(res == 'successful'){
      alert('product updated');
    }
    else{
      alert('an error occured');
    }
    this.getProducts();
  })
}


onDelete(item:any)
{
  if(confirm("you really want to remove this product"))
  {
    this.service.deleteProduct(item.productCode).subscribe((res:any)=>{
      if(res == 'true'){
        alert('product successfully removed')
      }
      else{
        alert('an error occured')
      }
    })
    this.getProducts();
  }
}

get ProductCode(){
  return this.addProductForm.get('productCode') as FormControl;
}
get Name(){
  return this.addProductForm.get('name') as FormControl;
}
get Brand(){
  return this.addProductForm.get('brand') as FormControl;
}
get Category(){
  return this.addProductForm.get('category') as FormControl;
}
get SellingPrice(){
  return this.addProductForm.get('sellingPrice') as FormControl;
}
get PurchasePrice(){
  return this.addProductForm.get('purchasePrice') as FormControl;
}
get PurchaseDate(){
  return this.addProductForm.get('purchaseDate') as FormControl;
}
get Stock(){
  return this.addProductForm.get('stock') as FormControl;
}



get editName(){
  return this.editProductForm.get('name') as FormControl;
}
get editBrand(){
  return this.editProductForm.get('brand') as FormControl;
}
get editCategory(){
  return this.editProductForm.get('category') as FormControl;
}
get editSellingPrice(){
  return this.editProductForm.get('sellingPrice') as FormControl;
}
get editPurchasePrice(){
  return this.editProductForm.get('purchasePrice') as FormControl;
}
get editPurchaseDate(){
  return this.editProductForm.get('purchaseDate') as FormControl;
}
get editStock(){
  return this.editProductForm.get('stock') as FormControl;
}


}
