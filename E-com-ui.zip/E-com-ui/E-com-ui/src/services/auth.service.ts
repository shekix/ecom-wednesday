import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  http = inject(HttpClient)
  
  private countryUrl = 'https://localhost:7051/api/CountryState/country';
  private stateUrl = 'https://localhost:7051/api/CountryState/states?id=';
  private userUrl = 'https://localhost:7051/api/User'
  
  public getCountries():Observable<any[]>{
   return this.http.get<any[]>(this.countryUrl);
  }

  public getStates(id:any):Observable<any[]>{
   return this.http.get<any[]>(`${this.stateUrl}${id}`);
  }

  public getRoles():Observable<any[]>{
    return this.http.get<any[]>(`${this.userUrl}/roles`);
   }

  public registerUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/Register`,data );
  }

  public loginUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/Login`,data ,{responseType :'text' as 'json'});
  }

  public verifyOtp(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/2FA`,data,{responseType :'text' as 'json'});
  }

  public forgotPass(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/ForgotPass?email=${data}`,data,{responseType :'text' as 'json'});
  }

  public changePass(data:any):Observable<any>{
    return this.http.put<any>(`${this.userUrl}/ChangePass`,data,{responseType :'text' as 'json'});
  }

  isAdminLoggedin(){
    return sessionStorage.getItem('role')=='Admin' ? true : false;
  }

  isCustomerLoggedin(){
    return sessionStorage.getItem('role')=='Customer' ? true : false;
  }

  isLoggedin(){
    return sessionStorage.getItem('token') ? true : false;
  }

  logout(){
    sessionStorage.clear();
  }

}
