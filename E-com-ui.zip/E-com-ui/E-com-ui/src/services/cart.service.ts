import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  http = inject(HttpClient)

  private cartUrl = 'https://localhost:7051/api/Cart';

  cartSize : BehaviorSubject<number> = new BehaviorSubject(0);

  currentCartSize = this.cartSize.asObservable();

  updateCartSize(size:number){
    this.cartSize.next(size);
  }

  public addToCart(id:any,data:any):Observable<any>{
    return this.http.post<any>(`${this.cartUrl}/addToCart?UserId=${id}`,data ,{responseType :'text' as 'json'});
  }

  public getCartData(id:any):Observable<any>{
    return this.http.get<any>(`${this.cartUrl}/cartDetails?UserId=${id}`);
  }

  public decrementQuantity(data:any):Observable<any>{
    return this.http.put<any>(`${this.cartUrl}/decrementQuantity`,data,{responseType :'text' as 'json'});
  }

  public removeProduct(ProductId:any,CartId:any):Observable<any>{
    return this.http.delete<any>(`${this.cartUrl}/remove?ProductId=${ProductId}&CartId=${CartId}`,{responseType :'text' as 'json'});
  }

}
