import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  http = inject(HttpClient)
  

  private userUrl = 'https://localhost:7051/api/User/user';

  public getUser(username:any):Observable<any[]>{
    return this.http.get<any[]>(`${this.userUrl}?username=${username}`);
   }

   public updateUser(data:any):Observable<any[]>{
    return this.http.put<any[]>(`${this.userUrl}`,data,{responseType :'text' as 'json'});
   }

   public updateUserAddress(data:any):Observable<any[]>{
    return this.http.put<any[]>(`https://localhost:7051/api/User/address`,data,{responseType :'text' as 'json'});
   }
  

}
