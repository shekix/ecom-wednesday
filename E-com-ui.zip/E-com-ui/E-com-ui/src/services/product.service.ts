import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  http = inject(HttpClient)

  productUrl = 'https://localhost:7051/api/Products';

  public getProducts():Observable<any[]>{
    return this.http.get<any[]>(`${this.productUrl}/All`);
  }

  public addProduct(data:any):Observable<any>{
    return this.http.post<any>(`${this.productUrl}/Add`,data );
  }

  public updateProduct(data:any):Observable<any[]>{
    return this.http.put<any[]>(`${this.productUrl}/Update`,data,{responseType :'text' as 'json'});
   }

   public deleteProduct(id:any):Observable<any[]>{
    return this.http.delete<any[]>(`${this.productUrl}/Remove?ProductCode=${id}`,{responseType :'text' as 'json'});
   }

}
