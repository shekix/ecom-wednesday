import { Routes } from '@angular/router';
import { LoginComponent } from '../components/login/login.component';
import { RegistrationComponent } from '../components/registration/registration.component';
import { HomeComponent } from '../components/home/home.component';
import { ProfileComponent } from '../components/profile/profile.component';
import { ChangePassComponent } from '../components/change-pass/change-pass.component';
import { ProductMasterComponent } from '../components/product-master/product-master.component';
import { ProductListingComponent } from '../components/product-listing/product-listing.component';
import { CartComponent } from '../components/cart/cart.component';
import { ReceiptComponent } from '../components/receipt/receipt.component';
import { adminGuard } from '../guards/admin.guard';
import { customerGuard } from '../guards/customer.guard';
import { masterGuard } from '../guards/master.guard';

export const routes: Routes = [
    {
        path:'',
        component:LoginComponent
    },
    {
        path:'login',
        component:LoginComponent
    },
    {
        path:'register',
        component:RegistrationComponent
    },
    {
        path:'home',
        component:HomeComponent,
        canActivate:[masterGuard],
        children:[
            {
                path:'profile',
                component:ProfileComponent
            },
            {
                path:'changePass',
                component:ChangePassComponent
            },
            {
                path:'admin',
                component:ProductMasterComponent,
                canActivate:[adminGuard]
            },
            {
                path:'productListing',
                component:ProductListingComponent,
                canActivate:[customerGuard]
            },
            {
                path:'cart',
                component:CartComponent,
                canActivate:[customerGuard]
            },
            {
                path:'receipt',
                component:ReceiptComponent,
                canActivate:[customerGuard]
            }
        ]
    }
];
